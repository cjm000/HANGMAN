﻿namespace DSA_Final
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            class1p1 = new Form_Controls.Class1P();
            class1p2 = new Form_Controls.Class1P();
            class1p3 = new Form_Controls.Class1P();
            class1p4 = new Form_Controls.Class1P();
            class1p5 = new Form_Controls.Class1P();
            class1p6 = new Form_Controls.Class1P();
            class1p7 = new Form_Controls.Class1P();
            class1p8 = new Form_Controls.Class1P();
            class1p9 = new Form_Controls.Class1P();
            class1p10 = new Form_Controls.Class1P();
            class1p11 = new Form_Controls.Class1P();
            class1p12 = new Form_Controls.Class1P();
            class1p13 = new Form_Controls.Class1P();
            class1p14 = new Form_Controls.Class1P();
            class1p15 = new Form_Controls.Class1P();
            class1p16 = new Form_Controls.Class1P();
            class1p17 = new Form_Controls.Class1P();
            class1p18 = new Form_Controls.Class1P();
            class1p19 = new Form_Controls.Class1P();
            class1p20 = new Form_Controls.Class1P();
            class1p21 = new Form_Controls.Class1P();
            class1p22 = new Form_Controls.Class1P();
            class1p23 = new Form_Controls.Class1P();
            class1p24 = new Form_Controls.Class1P();
            class1p25 = new Form_Controls.Class1P();
            class1p26 = new Form_Controls.Class1P();
            class1p27 = new Form_Controls.Class1P();
            class1p28 = new Form_Controls.Class1P();
            class1p29 = new Form_Controls.Class1P();
            class1p30 = new Form_Controls.Class1P();
            class1p31 = new Form_Controls.Class1P();
            class1p32 = new Form_Controls.Class1P();
            class1p33 = new Form_Controls.Class1P();
            class1p34 = new Form_Controls.Class1P();
            class1p35 = new Form_Controls.Class1P();
            class1p36 = new Form_Controls.Class1P();
            class1p37 = new Form_Controls.Class1P();
            class1p38 = new Form_Controls.Class1P();
            class1p39 = new Form_Controls.Class1P();
            class1p40 = new Form_Controls.Class1P();
            classK = new Form_Controls.Class1P();
            classJ = new Form_Controls.Class1P();
            classL = new Form_Controls.Class1P();
            classH = new Form_Controls.Class1P();
            classG = new Form_Controls.Class1P();
            classF = new Form_Controls.Class1P();
            classD = new Form_Controls.Class1P();
            classS = new Form_Controls.Class1P();
            classA = new Form_Controls.Class1P();
            classM = new Form_Controls.Class1P();
            classN = new Form_Controls.Class1P();
            classB = new Form_Controls.Class1P();
            classV = new Form_Controls.Class1P();
            classC = new Form_Controls.Class1P();
            classX = new Form_Controls.Class1P();
            classZ = new Form_Controls.Class1P();
            class1p59 = new Form_Controls.Class1P();
            class1p60 = new Form_Controls.Class1P();
            class1p61 = new Form_Controls.Class1P();
            class1p62 = new Form_Controls.Class1P();
            class1p63 = new Form_Controls.Class1P();
            class1p64 = new Form_Controls.Class1P();
            class1p65 = new Form_Controls.Class1P();
            class1p66 = new Form_Controls.Class1P();
            class1p67 = new Form_Controls.Class1P();
            class1p68 = new Form_Controls.Class1P();
            class1p69 = new Form_Controls.Class1P();
            class1p70 = new Form_Controls.Class1P();
            class1p71 = new Form_Controls.Class1P();
            class1p72 = new Form_Controls.Class1P();
            class1p73 = new Form_Controls.Class1P();
            class1p74 = new Form_Controls.Class1P();
            class1p75 = new Form_Controls.Class1P();
            class1p76 = new Form_Controls.Class1P();
            class1p77 = new Form_Controls.Class1P();
            class1p78 = new Form_Controls.Class1P();
            pictureBox1 = new PictureBox();
            classDelete = new Form_Controls.Class1P();
            label1 = new Label();
            classEnter = new Form_Controls.Class1P();
            InputLetter = new Label();
            groupBox1 = new GroupBox();
            labelWord = new Label();
            pictureHead = new PictureBox();
            pictureLeft = new PictureBox();
            pictureBody = new PictureBox();
            pictureRight = new PictureBox();
            pictureLegs = new PictureBox();
            pictureBox2 = new PictureBox();
            pictureBox3 = new PictureBox();
            labelLives = new Label();
            label3 = new Label();
            label4 = new Label();
            labelStreak = new Label();
            labelScores = new Label();
            classHint = new Form_Controls.Class1P();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureHead).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureLeft).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBody).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureRight).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureLegs).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            SuspendLayout();
            // 
            // class1p1
            // 
            class1p1.BackColor = Color.FromArgb(106, 149, 147);
            class1p1.BorderColor = Color.PaleVioletRed;
            class1p1.BorderRadius = 30;
            class1p1.BorderSize = 0;
            class1p1.FlatAppearance.BorderSize = 0;
            class1p1.FlatStyle = FlatStyle.Flat;
            class1p1.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p1.ForeColor = Color.White;
            class1p1.Location = new Point(35, 678);
            class1p1.Name = "class1p1";
            class1p1.Size = new Size(48, 63);
            class1p1.TabIndex = 6;
            class1p1.Text = "Q";
            class1p1.UseVisualStyleBackColor = false;
            // 
            // class1p2
            // 
            class1p2.BackColor = Color.FromArgb(106, 149, 147);
            class1p2.BorderColor = Color.PaleVioletRed;
            class1p2.BorderRadius = 30;
            class1p2.BorderSize = 0;
            class1p2.FlatAppearance.BorderSize = 0;
            class1p2.FlatStyle = FlatStyle.Flat;
            class1p2.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p2.ForeColor = Color.White;
            class1p2.Location = new Point(89, 678);
            class1p2.Name = "class1p2";
            class1p2.Size = new Size(48, 63);
            class1p2.TabIndex = 8;
            class1p2.Text = "W";
            class1p2.UseVisualStyleBackColor = false;
            // 
            // class1p3
            // 
            class1p3.BackColor = Color.FromArgb(106, 149, 147);
            class1p3.BorderColor = Color.PaleVioletRed;
            class1p3.BorderRadius = 30;
            class1p3.BorderSize = 0;
            class1p3.FlatAppearance.BorderSize = 0;
            class1p3.FlatStyle = FlatStyle.Flat;
            class1p3.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p3.ForeColor = Color.White;
            class1p3.Location = new Point(202, 678);
            class1p3.Name = "class1p3";
            class1p3.Size = new Size(48, 63);
            class1p3.TabIndex = 10;
            class1p3.Text = "R";
            class1p3.UseVisualStyleBackColor = false;
            // 
            // class1p4
            // 
            class1p4.BackColor = Color.FromArgb(106, 149, 147);
            class1p4.BorderColor = Color.PaleVioletRed;
            class1p4.BorderRadius = 30;
            class1p4.BorderSize = 0;
            class1p4.FlatAppearance.BorderSize = 0;
            class1p4.FlatStyle = FlatStyle.Flat;
            class1p4.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p4.ForeColor = Color.White;
            class1p4.Location = new Point(148, 678);
            class1p4.Name = "class1p4";
            class1p4.Size = new Size(48, 63);
            class1p4.TabIndex = 9;
            class1p4.Text = "E";
            class1p4.UseVisualStyleBackColor = false;
            // 
            // class1p5
            // 
            class1p5.BackColor = Color.FromArgb(106, 149, 147);
            class1p5.BorderColor = Color.PaleVioletRed;
            class1p5.BorderRadius = 30;
            class1p5.BorderSize = 0;
            class1p5.FlatAppearance.BorderSize = 0;
            class1p5.FlatStyle = FlatStyle.Flat;
            class1p5.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p5.ForeColor = Color.White;
            class1p5.Location = new Point(310, 678);
            class1p5.Name = "class1p5";
            class1p5.Size = new Size(48, 63);
            class1p5.TabIndex = 12;
            class1p5.Text = "Y";
            class1p5.UseVisualStyleBackColor = false;
            // 
            // class1p6
            // 
            class1p6.BackColor = Color.FromArgb(106, 149, 147);
            class1p6.BorderColor = Color.PaleVioletRed;
            class1p6.BorderRadius = 30;
            class1p6.BorderSize = 0;
            class1p6.FlatAppearance.BorderSize = 0;
            class1p6.FlatStyle = FlatStyle.Flat;
            class1p6.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p6.ForeColor = Color.White;
            class1p6.Location = new Point(256, 678);
            class1p6.Name = "class1p6";
            class1p6.Size = new Size(48, 63);
            class1p6.TabIndex = 11;
            class1p6.Text = "T";
            class1p6.UseVisualStyleBackColor = false;
            // 
            // class1p7
            // 
            class1p7.BackColor = Color.FromArgb(106, 149, 147);
            class1p7.BorderColor = Color.PaleVioletRed;
            class1p7.BorderRadius = 30;
            class1p7.BorderSize = 0;
            class1p7.FlatAppearance.BorderSize = 0;
            class1p7.FlatStyle = FlatStyle.Flat;
            class1p7.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p7.ForeColor = Color.White;
            class1p7.Location = new Point(472, 678);
            class1p7.Name = "class1p7";
            class1p7.Size = new Size(48, 63);
            class1p7.TabIndex = 14;
            class1p7.Text = "O";
            class1p7.UseVisualStyleBackColor = false;
            // 
            // class1p8
            // 
            class1p8.BackColor = Color.FromArgb(106, 149, 147);
            class1p8.BorderColor = Color.PaleVioletRed;
            class1p8.BorderRadius = 30;
            class1p8.BorderSize = 0;
            class1p8.FlatAppearance.BorderSize = 0;
            class1p8.FlatStyle = FlatStyle.Flat;
            class1p8.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p8.ForeColor = Color.White;
            class1p8.Location = new Point(526, 678);
            class1p8.Name = "class1p8";
            class1p8.Size = new Size(48, 63);
            class1p8.TabIndex = 13;
            class1p8.Text = "P";
            class1p8.UseVisualStyleBackColor = false;
            // 
            // class1p9
            // 
            class1p9.BackColor = Color.FromArgb(106, 149, 147);
            class1p9.BorderColor = Color.PaleVioletRed;
            class1p9.BorderRadius = 30;
            class1p9.BorderSize = 0;
            class1p9.FlatAppearance.BorderSize = 0;
            class1p9.FlatStyle = FlatStyle.Flat;
            class1p9.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p9.ForeColor = Color.White;
            class1p9.Location = new Point(418, 678);
            class1p9.Name = "class1p9";
            class1p9.Size = new Size(48, 63);
            class1p9.TabIndex = 16;
            class1p9.Text = "I";
            class1p9.UseVisualStyleBackColor = false;
            // 
            // class1p10
            // 
            class1p10.BackColor = Color.FromArgb(106, 149, 147);
            class1p10.BorderColor = Color.PaleVioletRed;
            class1p10.BorderRadius = 30;
            class1p10.BorderSize = 0;
            class1p10.FlatAppearance.BorderSize = 0;
            class1p10.FlatStyle = FlatStyle.Flat;
            class1p10.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p10.ForeColor = Color.White;
            class1p10.Location = new Point(364, 678);
            class1p10.Name = "class1p10";
            class1p10.Size = new Size(48, 63);
            class1p10.TabIndex = 15;
            class1p10.Text = "U";
            class1p10.UseVisualStyleBackColor = false;
            // 
            // class1p11
            // 
            class1p11.BackColor = Color.FromArgb(106, 149, 147);
            class1p11.BorderColor = Color.PaleVioletRed;
            class1p11.BorderRadius = 30;
            class1p11.BorderSize = 0;
            class1p11.FlatAppearance.BorderSize = 0;
            class1p11.FlatStyle = FlatStyle.Flat;
            class1p11.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p11.ForeColor = Color.White;
            class1p11.Location = new Point(418, 773);
            class1p11.Name = "class1p11";
            class1p11.Size = new Size(0, 0);
            class1p11.TabIndex = 26;
            class1p11.Text = "W";
            class1p11.UseVisualStyleBackColor = false;
            // 
            // class1p12
            // 
            class1p12.BackColor = Color.FromArgb(106, 149, 147);
            class1p12.BorderColor = Color.PaleVioletRed;
            class1p12.BorderRadius = 30;
            class1p12.BorderSize = 0;
            class1p12.FlatAppearance.BorderSize = 0;
            class1p12.FlatStyle = FlatStyle.Flat;
            class1p12.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p12.ForeColor = Color.White;
            class1p12.Location = new Point(371, 773);
            class1p12.Name = "class1p12";
            class1p12.Size = new Size(0, 0);
            class1p12.TabIndex = 25;
            class1p12.Text = "W";
            class1p12.UseVisualStyleBackColor = false;
            // 
            // class1p13
            // 
            class1p13.BackColor = Color.FromArgb(106, 149, 147);
            class1p13.BorderColor = Color.PaleVioletRed;
            class1p13.BorderRadius = 30;
            class1p13.BorderSize = 0;
            class1p13.FlatAppearance.BorderSize = 0;
            class1p13.FlatStyle = FlatStyle.Flat;
            class1p13.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p13.ForeColor = Color.White;
            class1p13.Location = new Point(465, 773);
            class1p13.Name = "class1p13";
            class1p13.Size = new Size(0, 0);
            class1p13.TabIndex = 24;
            class1p13.Text = "W";
            class1p13.UseVisualStyleBackColor = false;
            // 
            // class1p14
            // 
            class1p14.BackColor = Color.FromArgb(106, 149, 147);
            class1p14.BorderColor = Color.PaleVioletRed;
            class1p14.BorderRadius = 30;
            class1p14.BorderSize = 0;
            class1p14.FlatAppearance.BorderSize = 0;
            class1p14.FlatStyle = FlatStyle.Flat;
            class1p14.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p14.ForeColor = Color.White;
            class1p14.Location = new Point(512, 773);
            class1p14.Name = "class1p14";
            class1p14.Size = new Size(0, 0);
            class1p14.TabIndex = 23;
            class1p14.Text = "W";
            class1p14.UseVisualStyleBackColor = false;
            // 
            // class1p15
            // 
            class1p15.BackColor = Color.FromArgb(106, 149, 147);
            class1p15.BorderColor = Color.PaleVioletRed;
            class1p15.BorderRadius = 30;
            class1p15.BorderSize = 0;
            class1p15.FlatAppearance.BorderSize = 0;
            class1p15.FlatStyle = FlatStyle.Flat;
            class1p15.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p15.ForeColor = Color.White;
            class1p15.Location = new Point(322, 773);
            class1p15.Name = "class1p15";
            class1p15.Size = new Size(0, 0);
            class1p15.TabIndex = 22;
            class1p15.Text = "W";
            class1p15.UseVisualStyleBackColor = false;
            // 
            // class1p16
            // 
            class1p16.BackColor = Color.FromArgb(106, 149, 147);
            class1p16.BorderColor = Color.PaleVioletRed;
            class1p16.BorderRadius = 30;
            class1p16.BorderSize = 0;
            class1p16.FlatAppearance.BorderSize = 0;
            class1p16.FlatStyle = FlatStyle.Flat;
            class1p16.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p16.ForeColor = Color.White;
            class1p16.Location = new Point(275, 773);
            class1p16.Name = "class1p16";
            class1p16.Size = new Size(0, 0);
            class1p16.TabIndex = 21;
            class1p16.Text = "W";
            class1p16.UseVisualStyleBackColor = false;
            // 
            // class1p17
            // 
            class1p17.BackColor = Color.FromArgb(106, 149, 147);
            class1p17.BorderColor = Color.PaleVioletRed;
            class1p17.BorderRadius = 30;
            class1p17.BorderSize = 0;
            class1p17.FlatAppearance.BorderSize = 0;
            class1p17.FlatStyle = FlatStyle.Flat;
            class1p17.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p17.ForeColor = Color.White;
            class1p17.Location = new Point(225, 773);
            class1p17.Name = "class1p17";
            class1p17.Size = new Size(0, 0);
            class1p17.TabIndex = 20;
            class1p17.Text = "W";
            class1p17.UseVisualStyleBackColor = false;
            // 
            // class1p18
            // 
            class1p18.BackColor = Color.FromArgb(106, 149, 147);
            class1p18.BorderColor = Color.PaleVioletRed;
            class1p18.BorderRadius = 30;
            class1p18.BorderSize = 0;
            class1p18.FlatAppearance.BorderSize = 0;
            class1p18.FlatStyle = FlatStyle.Flat;
            class1p18.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p18.ForeColor = Color.White;
            class1p18.Location = new Point(178, 773);
            class1p18.Name = "class1p18";
            class1p18.Size = new Size(0, 0);
            class1p18.TabIndex = 19;
            class1p18.Text = "W";
            class1p18.UseVisualStyleBackColor = false;
            // 
            // class1p19
            // 
            class1p19.BackColor = Color.FromArgb(106, 149, 147);
            class1p19.BorderColor = Color.PaleVioletRed;
            class1p19.BorderRadius = 30;
            class1p19.BorderSize = 0;
            class1p19.FlatAppearance.BorderSize = 0;
            class1p19.FlatStyle = FlatStyle.Flat;
            class1p19.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p19.ForeColor = Color.White;
            class1p19.Location = new Point(128, 773);
            class1p19.Name = "class1p19";
            class1p19.Size = new Size(0, 0);
            class1p19.TabIndex = 18;
            class1p19.Text = "W";
            class1p19.UseVisualStyleBackColor = false;
            // 
            // class1p20
            // 
            class1p20.BackColor = Color.FromArgb(106, 149, 147);
            class1p20.BorderColor = Color.PaleVioletRed;
            class1p20.BorderRadius = 30;
            class1p20.BorderSize = 0;
            class1p20.FlatAppearance.BorderSize = 0;
            class1p20.FlatStyle = FlatStyle.Flat;
            class1p20.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p20.ForeColor = Color.White;
            class1p20.Location = new Point(81, 773);
            class1p20.Name = "class1p20";
            class1p20.Size = new Size(0, 0);
            class1p20.TabIndex = 17;
            class1p20.Text = "W";
            class1p20.UseVisualStyleBackColor = false;
            // 
            // class1p21
            // 
            class1p21.BackColor = Color.FromArgb(106, 149, 147);
            class1p21.BorderColor = Color.PaleVioletRed;
            class1p21.BorderRadius = 30;
            class1p21.BorderSize = 0;
            class1p21.FlatAppearance.BorderSize = 0;
            class1p21.FlatStyle = FlatStyle.Flat;
            class1p21.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p21.ForeColor = Color.White;
            class1p21.Location = new Point(424, 836);
            class1p21.Name = "class1p21";
            class1p21.Size = new Size(0, 0);
            class1p21.TabIndex = 36;
            class1p21.Text = "W";
            class1p21.UseVisualStyleBackColor = false;
            // 
            // class1p22
            // 
            class1p22.BackColor = Color.FromArgb(106, 149, 147);
            class1p22.BorderColor = Color.PaleVioletRed;
            class1p22.BorderRadius = 30;
            class1p22.BorderSize = 0;
            class1p22.FlatAppearance.BorderSize = 0;
            class1p22.FlatStyle = FlatStyle.Flat;
            class1p22.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p22.ForeColor = Color.White;
            class1p22.Location = new Point(377, 836);
            class1p22.Name = "class1p22";
            class1p22.Size = new Size(0, 0);
            class1p22.TabIndex = 35;
            class1p22.Text = "W";
            class1p22.UseVisualStyleBackColor = false;
            // 
            // class1p23
            // 
            class1p23.BackColor = Color.FromArgb(106, 149, 147);
            class1p23.BorderColor = Color.PaleVioletRed;
            class1p23.BorderRadius = 30;
            class1p23.BorderSize = 0;
            class1p23.FlatAppearance.BorderSize = 0;
            class1p23.FlatStyle = FlatStyle.Flat;
            class1p23.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p23.ForeColor = Color.White;
            class1p23.Location = new Point(471, 836);
            class1p23.Name = "class1p23";
            class1p23.Size = new Size(0, 0);
            class1p23.TabIndex = 34;
            class1p23.Text = "W";
            class1p23.UseVisualStyleBackColor = false;
            // 
            // class1p24
            // 
            class1p24.BackColor = Color.FromArgb(106, 149, 147);
            class1p24.BorderColor = Color.PaleVioletRed;
            class1p24.BorderRadius = 30;
            class1p24.BorderSize = 0;
            class1p24.FlatAppearance.BorderSize = 0;
            class1p24.FlatStyle = FlatStyle.Flat;
            class1p24.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p24.ForeColor = Color.White;
            class1p24.Location = new Point(518, 836);
            class1p24.Name = "class1p24";
            class1p24.Size = new Size(0, 0);
            class1p24.TabIndex = 33;
            class1p24.Text = "W";
            class1p24.UseVisualStyleBackColor = false;
            // 
            // class1p25
            // 
            class1p25.BackColor = Color.FromArgb(106, 149, 147);
            class1p25.BorderColor = Color.PaleVioletRed;
            class1p25.BorderRadius = 30;
            class1p25.BorderSize = 0;
            class1p25.FlatAppearance.BorderSize = 0;
            class1p25.FlatStyle = FlatStyle.Flat;
            class1p25.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p25.ForeColor = Color.White;
            class1p25.Location = new Point(328, 836);
            class1p25.Name = "class1p25";
            class1p25.Size = new Size(0, 0);
            class1p25.TabIndex = 32;
            class1p25.Text = "W";
            class1p25.UseVisualStyleBackColor = false;
            // 
            // class1p26
            // 
            class1p26.BackColor = Color.FromArgb(106, 149, 147);
            class1p26.BorderColor = Color.PaleVioletRed;
            class1p26.BorderRadius = 30;
            class1p26.BorderSize = 0;
            class1p26.FlatAppearance.BorderSize = 0;
            class1p26.FlatStyle = FlatStyle.Flat;
            class1p26.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p26.ForeColor = Color.White;
            class1p26.Location = new Point(281, 836);
            class1p26.Name = "class1p26";
            class1p26.Size = new Size(0, 0);
            class1p26.TabIndex = 31;
            class1p26.Text = "W";
            class1p26.UseVisualStyleBackColor = false;
            // 
            // class1p27
            // 
            class1p27.BackColor = Color.FromArgb(106, 149, 147);
            class1p27.BorderColor = Color.PaleVioletRed;
            class1p27.BorderRadius = 30;
            class1p27.BorderSize = 0;
            class1p27.FlatAppearance.BorderSize = 0;
            class1p27.FlatStyle = FlatStyle.Flat;
            class1p27.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p27.ForeColor = Color.White;
            class1p27.Location = new Point(231, 836);
            class1p27.Name = "class1p27";
            class1p27.Size = new Size(0, 0);
            class1p27.TabIndex = 30;
            class1p27.Text = "W";
            class1p27.UseVisualStyleBackColor = false;
            // 
            // class1p28
            // 
            class1p28.BackColor = Color.FromArgb(106, 149, 147);
            class1p28.BorderColor = Color.PaleVioletRed;
            class1p28.BorderRadius = 30;
            class1p28.BorderSize = 0;
            class1p28.FlatAppearance.BorderSize = 0;
            class1p28.FlatStyle = FlatStyle.Flat;
            class1p28.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p28.ForeColor = Color.White;
            class1p28.Location = new Point(184, 836);
            class1p28.Name = "class1p28";
            class1p28.Size = new Size(0, 0);
            class1p28.TabIndex = 29;
            class1p28.Text = "W";
            class1p28.UseVisualStyleBackColor = false;
            // 
            // class1p29
            // 
            class1p29.BackColor = Color.FromArgb(106, 149, 147);
            class1p29.BorderColor = Color.PaleVioletRed;
            class1p29.BorderRadius = 30;
            class1p29.BorderSize = 0;
            class1p29.FlatAppearance.BorderSize = 0;
            class1p29.FlatStyle = FlatStyle.Flat;
            class1p29.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p29.ForeColor = Color.White;
            class1p29.Location = new Point(134, 836);
            class1p29.Name = "class1p29";
            class1p29.Size = new Size(0, 0);
            class1p29.TabIndex = 28;
            class1p29.Text = "W";
            class1p29.UseVisualStyleBackColor = false;
            // 
            // class1p30
            // 
            class1p30.BackColor = Color.FromArgb(106, 149, 147);
            class1p30.BorderColor = Color.PaleVioletRed;
            class1p30.BorderRadius = 30;
            class1p30.BorderSize = 0;
            class1p30.FlatAppearance.BorderSize = 0;
            class1p30.FlatStyle = FlatStyle.Flat;
            class1p30.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p30.ForeColor = Color.White;
            class1p30.Location = new Point(87, 836);
            class1p30.Name = "class1p30";
            class1p30.Size = new Size(0, 0);
            class1p30.TabIndex = 27;
            class1p30.Text = "W";
            class1p30.UseVisualStyleBackColor = false;
            // 
            // class1p31
            // 
            class1p31.BackColor = Color.FromArgb(106, 149, 147);
            class1p31.BorderColor = Color.PaleVioletRed;
            class1p31.BorderRadius = 30;
            class1p31.BorderSize = 0;
            class1p31.FlatAppearance.BorderSize = 0;
            class1p31.FlatStyle = FlatStyle.Flat;
            class1p31.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p31.ForeColor = Color.White;
            class1p31.Location = new Point(433, 848);
            class1p31.Name = "class1p31";
            class1p31.Size = new Size(0, 0);
            class1p31.TabIndex = 56;
            class1p31.Text = "W";
            class1p31.UseVisualStyleBackColor = false;
            // 
            // class1p32
            // 
            class1p32.BackColor = Color.FromArgb(106, 149, 147);
            class1p32.BorderColor = Color.PaleVioletRed;
            class1p32.BorderRadius = 30;
            class1p32.BorderSize = 0;
            class1p32.FlatAppearance.BorderSize = 0;
            class1p32.FlatStyle = FlatStyle.Flat;
            class1p32.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p32.ForeColor = Color.White;
            class1p32.Location = new Point(386, 848);
            class1p32.Name = "class1p32";
            class1p32.Size = new Size(0, 0);
            class1p32.TabIndex = 55;
            class1p32.Text = "W";
            class1p32.UseVisualStyleBackColor = false;
            // 
            // class1p33
            // 
            class1p33.BackColor = Color.FromArgb(106, 149, 147);
            class1p33.BorderColor = Color.PaleVioletRed;
            class1p33.BorderRadius = 30;
            class1p33.BorderSize = 0;
            class1p33.FlatAppearance.BorderSize = 0;
            class1p33.FlatStyle = FlatStyle.Flat;
            class1p33.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p33.ForeColor = Color.White;
            class1p33.Location = new Point(480, 848);
            class1p33.Name = "class1p33";
            class1p33.Size = new Size(0, 0);
            class1p33.TabIndex = 54;
            class1p33.Text = "W";
            class1p33.UseVisualStyleBackColor = false;
            // 
            // class1p34
            // 
            class1p34.BackColor = Color.FromArgb(106, 149, 147);
            class1p34.BorderColor = Color.PaleVioletRed;
            class1p34.BorderRadius = 30;
            class1p34.BorderSize = 0;
            class1p34.FlatAppearance.BorderSize = 0;
            class1p34.FlatStyle = FlatStyle.Flat;
            class1p34.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p34.ForeColor = Color.White;
            class1p34.Location = new Point(527, 848);
            class1p34.Name = "class1p34";
            class1p34.Size = new Size(0, 0);
            class1p34.TabIndex = 53;
            class1p34.Text = "W";
            class1p34.UseVisualStyleBackColor = false;
            // 
            // class1p35
            // 
            class1p35.BackColor = Color.FromArgb(106, 149, 147);
            class1p35.BorderColor = Color.PaleVioletRed;
            class1p35.BorderRadius = 30;
            class1p35.BorderSize = 0;
            class1p35.FlatAppearance.BorderSize = 0;
            class1p35.FlatStyle = FlatStyle.Flat;
            class1p35.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p35.ForeColor = Color.White;
            class1p35.Location = new Point(337, 848);
            class1p35.Name = "class1p35";
            class1p35.Size = new Size(0, 0);
            class1p35.TabIndex = 52;
            class1p35.Text = "W";
            class1p35.UseVisualStyleBackColor = false;
            // 
            // class1p36
            // 
            class1p36.BackColor = Color.FromArgb(106, 149, 147);
            class1p36.BorderColor = Color.PaleVioletRed;
            class1p36.BorderRadius = 30;
            class1p36.BorderSize = 0;
            class1p36.FlatAppearance.BorderSize = 0;
            class1p36.FlatStyle = FlatStyle.Flat;
            class1p36.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p36.ForeColor = Color.White;
            class1p36.Location = new Point(290, 848);
            class1p36.Name = "class1p36";
            class1p36.Size = new Size(0, 0);
            class1p36.TabIndex = 51;
            class1p36.Text = "W";
            class1p36.UseVisualStyleBackColor = false;
            // 
            // class1p37
            // 
            class1p37.BackColor = Color.FromArgb(106, 149, 147);
            class1p37.BorderColor = Color.PaleVioletRed;
            class1p37.BorderRadius = 30;
            class1p37.BorderSize = 0;
            class1p37.FlatAppearance.BorderSize = 0;
            class1p37.FlatStyle = FlatStyle.Flat;
            class1p37.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p37.ForeColor = Color.White;
            class1p37.Location = new Point(240, 848);
            class1p37.Name = "class1p37";
            class1p37.Size = new Size(0, 0);
            class1p37.TabIndex = 50;
            class1p37.Text = "W";
            class1p37.UseVisualStyleBackColor = false;
            // 
            // class1p38
            // 
            class1p38.BackColor = Color.FromArgb(106, 149, 147);
            class1p38.BorderColor = Color.PaleVioletRed;
            class1p38.BorderRadius = 30;
            class1p38.BorderSize = 0;
            class1p38.FlatAppearance.BorderSize = 0;
            class1p38.FlatStyle = FlatStyle.Flat;
            class1p38.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p38.ForeColor = Color.White;
            class1p38.Location = new Point(193, 848);
            class1p38.Name = "class1p38";
            class1p38.Size = new Size(0, 0);
            class1p38.TabIndex = 49;
            class1p38.Text = "W";
            class1p38.UseVisualStyleBackColor = false;
            // 
            // class1p39
            // 
            class1p39.BackColor = Color.FromArgb(106, 149, 147);
            class1p39.BorderColor = Color.PaleVioletRed;
            class1p39.BorderRadius = 30;
            class1p39.BorderSize = 0;
            class1p39.FlatAppearance.BorderSize = 0;
            class1p39.FlatStyle = FlatStyle.Flat;
            class1p39.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p39.ForeColor = Color.White;
            class1p39.Location = new Point(143, 848);
            class1p39.Name = "class1p39";
            class1p39.Size = new Size(0, 0);
            class1p39.TabIndex = 48;
            class1p39.Text = "W";
            class1p39.UseVisualStyleBackColor = false;
            // 
            // class1p40
            // 
            class1p40.BackColor = Color.FromArgb(106, 149, 147);
            class1p40.BorderColor = Color.PaleVioletRed;
            class1p40.BorderRadius = 30;
            class1p40.BorderSize = 0;
            class1p40.FlatAppearance.BorderSize = 0;
            class1p40.FlatStyle = FlatStyle.Flat;
            class1p40.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p40.ForeColor = Color.White;
            class1p40.Location = new Point(96, 848);
            class1p40.Name = "class1p40";
            class1p40.Size = new Size(0, 0);
            class1p40.TabIndex = 47;
            class1p40.Text = "W";
            class1p40.UseVisualStyleBackColor = false;
            // 
            // classK
            // 
            classK.BackColor = Color.FromArgb(106, 149, 147);
            classK.BorderColor = Color.PaleVioletRed;
            classK.BorderRadius = 30;
            classK.BorderSize = 0;
            classK.FlatAppearance.BorderSize = 0;
            classK.FlatStyle = FlatStyle.Flat;
            classK.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            classK.ForeColor = Color.White;
            classK.Location = new Point(447, 758);
            classK.Name = "classK";
            classK.Size = new Size(48, 63);
            classK.TabIndex = 46;
            classK.Text = "K";
            classK.UseVisualStyleBackColor = false;
            // 
            // classJ
            // 
            classJ.BackColor = Color.FromArgb(106, 149, 147);
            classJ.BorderColor = Color.PaleVioletRed;
            classJ.BorderRadius = 30;
            classJ.BorderSize = 0;
            classJ.FlatAppearance.BorderSize = 0;
            classJ.FlatStyle = FlatStyle.Flat;
            classJ.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            classJ.ForeColor = Color.White;
            classJ.Location = new Point(393, 758);
            classJ.Name = "classJ";
            classJ.Size = new Size(48, 63);
            classJ.TabIndex = 45;
            classJ.Text = "J";
            classJ.UseVisualStyleBackColor = false;
            // 
            // classL
            // 
            classL.BackColor = Color.FromArgb(106, 149, 147);
            classL.BorderColor = Color.PaleVioletRed;
            classL.BorderRadius = 30;
            classL.BorderSize = 0;
            classL.FlatAppearance.BorderSize = 0;
            classL.FlatStyle = FlatStyle.Flat;
            classL.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            classL.ForeColor = Color.White;
            classL.Location = new Point(501, 758);
            classL.Name = "classL";
            classL.Size = new Size(48, 63);
            classL.TabIndex = 44;
            classL.Text = "L";
            classL.UseVisualStyleBackColor = false;
            // 
            // classH
            // 
            classH.BackColor = Color.FromArgb(106, 149, 147);
            classH.BorderColor = Color.PaleVioletRed;
            classH.BorderRadius = 30;
            classH.BorderSize = 0;
            classH.FlatAppearance.BorderSize = 0;
            classH.FlatStyle = FlatStyle.Flat;
            classH.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            classH.ForeColor = Color.White;
            classH.Location = new Point(339, 758);
            classH.Name = "classH";
            classH.Size = new Size(48, 63);
            classH.TabIndex = 42;
            classH.Text = "H";
            classH.UseVisualStyleBackColor = false;
            // 
            // classG
            // 
            classG.BackColor = Color.FromArgb(106, 149, 147);
            classG.BorderColor = Color.PaleVioletRed;
            classG.BorderRadius = 30;
            classG.BorderSize = 0;
            classG.FlatAppearance.BorderSize = 0;
            classG.FlatStyle = FlatStyle.Flat;
            classG.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            classG.ForeColor = Color.White;
            classG.Location = new Point(285, 758);
            classG.Name = "classG";
            classG.Size = new Size(48, 63);
            classG.TabIndex = 41;
            classG.Text = "G";
            classG.UseVisualStyleBackColor = false;
            // 
            // classF
            // 
            classF.BackColor = Color.FromArgb(106, 149, 147);
            classF.BorderColor = Color.PaleVioletRed;
            classF.BorderRadius = 30;
            classF.BorderSize = 0;
            classF.FlatAppearance.BorderSize = 0;
            classF.FlatStyle = FlatStyle.Flat;
            classF.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            classF.ForeColor = Color.White;
            classF.Location = new Point(231, 758);
            classF.Name = "classF";
            classF.Size = new Size(48, 63);
            classF.TabIndex = 40;
            classF.Text = "F";
            classF.UseVisualStyleBackColor = false;
            // 
            // classD
            // 
            classD.BackColor = Color.FromArgb(106, 149, 147);
            classD.BorderColor = Color.PaleVioletRed;
            classD.BorderRadius = 30;
            classD.BorderSize = 0;
            classD.FlatAppearance.BorderSize = 0;
            classD.FlatStyle = FlatStyle.Flat;
            classD.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            classD.ForeColor = Color.White;
            classD.Location = new Point(177, 758);
            classD.Name = "classD";
            classD.Size = new Size(48, 63);
            classD.TabIndex = 39;
            classD.Text = "D";
            classD.UseVisualStyleBackColor = false;
            // 
            // classS
            // 
            classS.BackColor = Color.FromArgb(106, 149, 147);
            classS.BorderColor = Color.PaleVioletRed;
            classS.BorderRadius = 30;
            classS.BorderSize = 0;
            classS.FlatAppearance.BorderSize = 0;
            classS.FlatStyle = FlatStyle.Flat;
            classS.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            classS.ForeColor = Color.White;
            classS.Location = new Point(118, 758);
            classS.Name = "classS";
            classS.Size = new Size(48, 63);
            classS.TabIndex = 38;
            classS.Text = "S";
            classS.UseVisualStyleBackColor = false;
            // 
            // classA
            // 
            classA.BackColor = Color.FromArgb(106, 149, 147);
            classA.BorderColor = Color.PaleVioletRed;
            classA.BorderRadius = 30;
            classA.BorderSize = 0;
            classA.FlatAppearance.BorderSize = 0;
            classA.FlatStyle = FlatStyle.Flat;
            classA.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            classA.ForeColor = Color.White;
            classA.Location = new Point(64, 758);
            classA.Name = "classA";
            classA.Size = new Size(48, 63);
            classA.TabIndex = 37;
            classA.Text = "A";
            classA.UseVisualStyleBackColor = false;
            // 
            // classM
            // 
            classM.BackColor = Color.FromArgb(106, 149, 147);
            classM.BorderColor = Color.PaleVioletRed;
            classM.BorderRadius = 30;
            classM.BorderSize = 0;
            classM.FlatAppearance.BorderSize = 0;
            classM.FlatStyle = FlatStyle.Flat;
            classM.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            classM.ForeColor = Color.White;
            classM.Location = new Point(418, 836);
            classM.Name = "classM";
            classM.Size = new Size(48, 63);
            classM.TabIndex = 84;
            classM.Text = "M";
            classM.UseVisualStyleBackColor = false;
            // 
            // classN
            // 
            classN.BackColor = Color.FromArgb(106, 149, 147);
            classN.BorderColor = Color.PaleVioletRed;
            classN.BorderRadius = 30;
            classN.BorderSize = 0;
            classN.FlatAppearance.BorderSize = 0;
            classN.FlatStyle = FlatStyle.Flat;
            classN.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            classN.ForeColor = Color.White;
            classN.Location = new Point(365, 836);
            classN.Name = "classN";
            classN.Size = new Size(48, 63);
            classN.TabIndex = 82;
            classN.Text = "N";
            classN.UseVisualStyleBackColor = false;
            // 
            // classB
            // 
            classB.BackColor = Color.FromArgb(106, 149, 147);
            classB.BorderColor = Color.PaleVioletRed;
            classB.BorderRadius = 30;
            classB.BorderSize = 0;
            classB.FlatAppearance.BorderSize = 0;
            classB.FlatStyle = FlatStyle.Flat;
            classB.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            classB.ForeColor = Color.White;
            classB.Location = new Point(310, 836);
            classB.Name = "classB";
            classB.Size = new Size(48, 63);
            classB.TabIndex = 81;
            classB.Text = "B";
            classB.UseVisualStyleBackColor = false;
            // 
            // classV
            // 
            classV.BackColor = Color.FromArgb(106, 149, 147);
            classV.BorderColor = Color.PaleVioletRed;
            classV.BorderRadius = 30;
            classV.BorderSize = 0;
            classV.FlatAppearance.BorderSize = 0;
            classV.FlatStyle = FlatStyle.Flat;
            classV.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            classV.ForeColor = Color.White;
            classV.Location = new Point(258, 836);
            classV.Name = "classV";
            classV.Size = new Size(48, 63);
            classV.TabIndex = 80;
            classV.Text = "V";
            classV.UseVisualStyleBackColor = false;
            // 
            // classC
            // 
            classC.BackColor = Color.FromArgb(106, 149, 147);
            classC.BorderColor = Color.PaleVioletRed;
            classC.BorderRadius = 30;
            classC.BorderSize = 0;
            classC.FlatAppearance.BorderSize = 0;
            classC.FlatStyle = FlatStyle.Flat;
            classC.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            classC.ForeColor = Color.White;
            classC.Location = new Point(202, 836);
            classC.Name = "classC";
            classC.Size = new Size(48, 63);
            classC.TabIndex = 79;
            classC.Text = "C";
            classC.UseVisualStyleBackColor = false;
            // 
            // classX
            // 
            classX.BackColor = Color.FromArgb(106, 149, 147);
            classX.BorderColor = Color.PaleVioletRed;
            classX.BorderRadius = 30;
            classX.BorderSize = 0;
            classX.FlatAppearance.BorderSize = 0;
            classX.FlatStyle = FlatStyle.Flat;
            classX.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            classX.ForeColor = Color.White;
            classX.Location = new Point(148, 836);
            classX.Name = "classX";
            classX.Size = new Size(48, 63);
            classX.TabIndex = 78;
            classX.Text = "X";
            classX.UseVisualStyleBackColor = false;
            // 
            // classZ
            // 
            classZ.BackColor = Color.FromArgb(106, 149, 147);
            classZ.BorderColor = Color.PaleVioletRed;
            classZ.BorderRadius = 30;
            classZ.BorderSize = 0;
            classZ.FlatAppearance.BorderSize = 0;
            classZ.FlatStyle = FlatStyle.Flat;
            classZ.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            classZ.ForeColor = Color.White;
            classZ.Location = new Point(89, 836);
            classZ.Name = "classZ";
            classZ.Size = new Size(48, 63);
            classZ.TabIndex = 77;
            classZ.Text = "Z";
            classZ.UseVisualStyleBackColor = false;
            // 
            // class1p59
            // 
            class1p59.BackColor = Color.FromArgb(106, 149, 147);
            class1p59.BorderColor = Color.PaleVioletRed;
            class1p59.BorderRadius = 30;
            class1p59.BorderSize = 0;
            class1p59.FlatAppearance.BorderSize = 0;
            class1p59.FlatStyle = FlatStyle.Flat;
            class1p59.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p59.ForeColor = Color.White;
            class1p59.Location = new Point(396, 940);
            class1p59.Name = "class1p59";
            class1p59.Size = new Size(0, 0);
            class1p59.TabIndex = 76;
            class1p59.Text = "W";
            class1p59.UseVisualStyleBackColor = false;
            // 
            // class1p60
            // 
            class1p60.BackColor = Color.FromArgb(106, 149, 147);
            class1p60.BorderColor = Color.PaleVioletRed;
            class1p60.BorderRadius = 30;
            class1p60.BorderSize = 0;
            class1p60.FlatAppearance.BorderSize = 0;
            class1p60.FlatStyle = FlatStyle.Flat;
            class1p60.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p60.ForeColor = Color.White;
            class1p60.Location = new Point(349, 940);
            class1p60.Name = "class1p60";
            class1p60.Size = new Size(0, 0);
            class1p60.TabIndex = 75;
            class1p60.Text = "W";
            class1p60.UseVisualStyleBackColor = false;
            // 
            // class1p61
            // 
            class1p61.BackColor = Color.FromArgb(106, 149, 147);
            class1p61.BorderColor = Color.PaleVioletRed;
            class1p61.BorderRadius = 30;
            class1p61.BorderSize = 0;
            class1p61.FlatAppearance.BorderSize = 0;
            class1p61.FlatStyle = FlatStyle.Flat;
            class1p61.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p61.ForeColor = Color.White;
            class1p61.Location = new Point(443, 940);
            class1p61.Name = "class1p61";
            class1p61.Size = new Size(0, 0);
            class1p61.TabIndex = 74;
            class1p61.Text = "W";
            class1p61.UseVisualStyleBackColor = false;
            // 
            // class1p62
            // 
            class1p62.BackColor = Color.FromArgb(106, 149, 147);
            class1p62.BorderColor = Color.PaleVioletRed;
            class1p62.BorderRadius = 30;
            class1p62.BorderSize = 0;
            class1p62.FlatAppearance.BorderSize = 0;
            class1p62.FlatStyle = FlatStyle.Flat;
            class1p62.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p62.ForeColor = Color.White;
            class1p62.Location = new Point(490, 940);
            class1p62.Name = "class1p62";
            class1p62.Size = new Size(0, 0);
            class1p62.TabIndex = 73;
            class1p62.Text = "W";
            class1p62.UseVisualStyleBackColor = false;
            // 
            // class1p63
            // 
            class1p63.BackColor = Color.FromArgb(106, 149, 147);
            class1p63.BorderColor = Color.PaleVioletRed;
            class1p63.BorderRadius = 30;
            class1p63.BorderSize = 0;
            class1p63.FlatAppearance.BorderSize = 0;
            class1p63.FlatStyle = FlatStyle.Flat;
            class1p63.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p63.ForeColor = Color.White;
            class1p63.Location = new Point(300, 940);
            class1p63.Name = "class1p63";
            class1p63.Size = new Size(0, 0);
            class1p63.TabIndex = 72;
            class1p63.Text = "W";
            class1p63.UseVisualStyleBackColor = false;
            // 
            // class1p64
            // 
            class1p64.BackColor = Color.FromArgb(106, 149, 147);
            class1p64.BorderColor = Color.PaleVioletRed;
            class1p64.BorderRadius = 30;
            class1p64.BorderSize = 0;
            class1p64.FlatAppearance.BorderSize = 0;
            class1p64.FlatStyle = FlatStyle.Flat;
            class1p64.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p64.ForeColor = Color.White;
            class1p64.Location = new Point(253, 940);
            class1p64.Name = "class1p64";
            class1p64.Size = new Size(0, 0);
            class1p64.TabIndex = 71;
            class1p64.Text = "W";
            class1p64.UseVisualStyleBackColor = false;
            // 
            // class1p65
            // 
            class1p65.BackColor = Color.FromArgb(106, 149, 147);
            class1p65.BorderColor = Color.PaleVioletRed;
            class1p65.BorderRadius = 30;
            class1p65.BorderSize = 0;
            class1p65.FlatAppearance.BorderSize = 0;
            class1p65.FlatStyle = FlatStyle.Flat;
            class1p65.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p65.ForeColor = Color.White;
            class1p65.Location = new Point(203, 940);
            class1p65.Name = "class1p65";
            class1p65.Size = new Size(0, 0);
            class1p65.TabIndex = 70;
            class1p65.Text = "W";
            class1p65.UseVisualStyleBackColor = false;
            // 
            // class1p66
            // 
            class1p66.BackColor = Color.FromArgb(106, 149, 147);
            class1p66.BorderColor = Color.PaleVioletRed;
            class1p66.BorderRadius = 30;
            class1p66.BorderSize = 0;
            class1p66.FlatAppearance.BorderSize = 0;
            class1p66.FlatStyle = FlatStyle.Flat;
            class1p66.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p66.ForeColor = Color.White;
            class1p66.Location = new Point(156, 940);
            class1p66.Name = "class1p66";
            class1p66.Size = new Size(0, 0);
            class1p66.TabIndex = 69;
            class1p66.Text = "W";
            class1p66.UseVisualStyleBackColor = false;
            // 
            // class1p67
            // 
            class1p67.BackColor = Color.FromArgb(106, 149, 147);
            class1p67.BorderColor = Color.PaleVioletRed;
            class1p67.BorderRadius = 30;
            class1p67.BorderSize = 0;
            class1p67.FlatAppearance.BorderSize = 0;
            class1p67.FlatStyle = FlatStyle.Flat;
            class1p67.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p67.ForeColor = Color.White;
            class1p67.Location = new Point(106, 940);
            class1p67.Name = "class1p67";
            class1p67.Size = new Size(0, 0);
            class1p67.TabIndex = 68;
            class1p67.Text = "W";
            class1p67.UseVisualStyleBackColor = false;
            // 
            // class1p68
            // 
            class1p68.BackColor = Color.FromArgb(106, 149, 147);
            class1p68.BorderColor = Color.PaleVioletRed;
            class1p68.BorderRadius = 30;
            class1p68.BorderSize = 0;
            class1p68.FlatAppearance.BorderSize = 0;
            class1p68.FlatStyle = FlatStyle.Flat;
            class1p68.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p68.ForeColor = Color.White;
            class1p68.Location = new Point(59, 940);
            class1p68.Name = "class1p68";
            class1p68.Size = new Size(0, 0);
            class1p68.TabIndex = 67;
            class1p68.Text = "W";
            class1p68.UseVisualStyleBackColor = false;
            // 
            // class1p69
            // 
            class1p69.BackColor = Color.FromArgb(106, 149, 147);
            class1p69.BorderColor = Color.PaleVioletRed;
            class1p69.BorderRadius = 30;
            class1p69.BorderSize = 0;
            class1p69.FlatAppearance.BorderSize = 0;
            class1p69.FlatStyle = FlatStyle.Flat;
            class1p69.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p69.ForeColor = Color.White;
            class1p69.Location = new Point(455, 851);
            class1p69.Name = "class1p69";
            class1p69.Size = new Size(0, 0);
            class1p69.TabIndex = 66;
            class1p69.Text = "W";
            class1p69.UseVisualStyleBackColor = false;
            // 
            // class1p70
            // 
            class1p70.BackColor = Color.FromArgb(106, 149, 147);
            class1p70.BorderColor = Color.PaleVioletRed;
            class1p70.BorderRadius = 30;
            class1p70.BorderSize = 0;
            class1p70.FlatAppearance.BorderSize = 0;
            class1p70.FlatStyle = FlatStyle.Flat;
            class1p70.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p70.ForeColor = Color.White;
            class1p70.Location = new Point(408, 851);
            class1p70.Name = "class1p70";
            class1p70.Size = new Size(0, 0);
            class1p70.TabIndex = 65;
            class1p70.Text = "W";
            class1p70.UseVisualStyleBackColor = false;
            // 
            // class1p71
            // 
            class1p71.BackColor = Color.FromArgb(106, 149, 147);
            class1p71.BorderColor = Color.PaleVioletRed;
            class1p71.BorderRadius = 30;
            class1p71.BorderSize = 0;
            class1p71.FlatAppearance.BorderSize = 0;
            class1p71.FlatStyle = FlatStyle.Flat;
            class1p71.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p71.ForeColor = Color.White;
            class1p71.Location = new Point(502, 851);
            class1p71.Name = "class1p71";
            class1p71.Size = new Size(0, 0);
            class1p71.TabIndex = 64;
            class1p71.Text = "W";
            class1p71.UseVisualStyleBackColor = false;
            // 
            // class1p72
            // 
            class1p72.BackColor = Color.FromArgb(106, 149, 147);
            class1p72.BorderColor = Color.PaleVioletRed;
            class1p72.BorderRadius = 30;
            class1p72.BorderSize = 0;
            class1p72.FlatAppearance.BorderSize = 0;
            class1p72.FlatStyle = FlatStyle.Flat;
            class1p72.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p72.ForeColor = Color.White;
            class1p72.Location = new Point(549, 851);
            class1p72.Name = "class1p72";
            class1p72.Size = new Size(0, 0);
            class1p72.TabIndex = 63;
            class1p72.Text = "W";
            class1p72.UseVisualStyleBackColor = false;
            // 
            // class1p73
            // 
            class1p73.BackColor = Color.FromArgb(106, 149, 147);
            class1p73.BorderColor = Color.PaleVioletRed;
            class1p73.BorderRadius = 30;
            class1p73.BorderSize = 0;
            class1p73.FlatAppearance.BorderSize = 0;
            class1p73.FlatStyle = FlatStyle.Flat;
            class1p73.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p73.ForeColor = Color.White;
            class1p73.Location = new Point(359, 851);
            class1p73.Name = "class1p73";
            class1p73.Size = new Size(0, 0);
            class1p73.TabIndex = 62;
            class1p73.Text = "W";
            class1p73.UseVisualStyleBackColor = false;
            // 
            // class1p74
            // 
            class1p74.BackColor = Color.FromArgb(106, 149, 147);
            class1p74.BorderColor = Color.PaleVioletRed;
            class1p74.BorderRadius = 30;
            class1p74.BorderSize = 0;
            class1p74.FlatAppearance.BorderSize = 0;
            class1p74.FlatStyle = FlatStyle.Flat;
            class1p74.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p74.ForeColor = Color.White;
            class1p74.Location = new Point(312, 851);
            class1p74.Name = "class1p74";
            class1p74.Size = new Size(0, 0);
            class1p74.TabIndex = 61;
            class1p74.Text = "W";
            class1p74.UseVisualStyleBackColor = false;
            // 
            // class1p75
            // 
            class1p75.BackColor = Color.FromArgb(106, 149, 147);
            class1p75.BorderColor = Color.PaleVioletRed;
            class1p75.BorderRadius = 30;
            class1p75.BorderSize = 0;
            class1p75.FlatAppearance.BorderSize = 0;
            class1p75.FlatStyle = FlatStyle.Flat;
            class1p75.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p75.ForeColor = Color.White;
            class1p75.Location = new Point(262, 851);
            class1p75.Name = "class1p75";
            class1p75.Size = new Size(0, 0);
            class1p75.TabIndex = 60;
            class1p75.Text = "W";
            class1p75.UseVisualStyleBackColor = false;
            // 
            // class1p76
            // 
            class1p76.BackColor = Color.FromArgb(106, 149, 147);
            class1p76.BorderColor = Color.PaleVioletRed;
            class1p76.BorderRadius = 30;
            class1p76.BorderSize = 0;
            class1p76.FlatAppearance.BorderSize = 0;
            class1p76.FlatStyle = FlatStyle.Flat;
            class1p76.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p76.ForeColor = Color.White;
            class1p76.Location = new Point(215, 851);
            class1p76.Name = "class1p76";
            class1p76.Size = new Size(0, 0);
            class1p76.TabIndex = 59;
            class1p76.Text = "W";
            class1p76.UseVisualStyleBackColor = false;
            // 
            // class1p77
            // 
            class1p77.BackColor = Color.FromArgb(106, 149, 147);
            class1p77.BorderColor = Color.PaleVioletRed;
            class1p77.BorderRadius = 30;
            class1p77.BorderSize = 0;
            class1p77.FlatAppearance.BorderSize = 0;
            class1p77.FlatStyle = FlatStyle.Flat;
            class1p77.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p77.ForeColor = Color.White;
            class1p77.Location = new Point(165, 851);
            class1p77.Name = "class1p77";
            class1p77.Size = new Size(0, 0);
            class1p77.TabIndex = 58;
            class1p77.Text = "W";
            class1p77.UseVisualStyleBackColor = false;
            // 
            // class1p78
            // 
            class1p78.BackColor = Color.FromArgb(106, 149, 147);
            class1p78.BorderColor = Color.PaleVioletRed;
            class1p78.BorderRadius = 30;
            class1p78.BorderSize = 0;
            class1p78.FlatAppearance.BorderSize = 0;
            class1p78.FlatStyle = FlatStyle.Flat;
            class1p78.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            class1p78.ForeColor = Color.White;
            class1p78.Location = new Point(118, 851);
            class1p78.Name = "class1p78";
            class1p78.Size = new Size(0, 0);
            class1p78.TabIndex = 57;
            class1p78.Text = "W";
            class1p78.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(-4, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(42, 42);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 7;
            pictureBox1.TabStop = false;
            // 
            // classDelete
            // 
            classDelete.BackColor = Color.FromArgb(106, 149, 147);
            classDelete.BackgroundImageLayout = ImageLayout.Zoom;
            classDelete.BorderColor = Color.PaleVioletRed;
            classDelete.BorderRadius = 30;
            classDelete.BorderSize = 0;
            classDelete.FlatAppearance.BorderSize = 0;
            classDelete.FlatStyle = FlatStyle.Flat;
            classDelete.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            classDelete.ForeColor = Color.White;
            classDelete.Image = (Image)resources.GetObject("classDelete.Image");
            classDelete.Location = new Point(473, 836);
            classDelete.Name = "classDelete";
            classDelete.Size = new Size(48, 63);
            classDelete.TabIndex = 85;
            classDelete.UseVisualStyleBackColor = false;
            classDelete.Click += classDelete_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(89, 588);
            label1.Name = "label1";
            label1.Size = new Size(169, 33);
            label1.TabIndex = 86;
            label1.Text = "Letter Input";
            // 
            // classEnter
            // 
            classEnter.BackColor = Color.FromArgb(106, 149, 147);
            classEnter.BorderColor = Color.PaleVioletRed;
            classEnter.BorderRadius = 30;
            classEnter.BorderSize = 0;
            classEnter.FlatAppearance.BorderSize = 0;
            classEnter.FlatStyle = FlatStyle.Flat;
            classEnter.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            classEnter.ForeColor = Color.White;
            classEnter.Location = new Point(378, 582);
            classEnter.Name = "classEnter";
            classEnter.Size = new Size(142, 44);
            classEnter.TabIndex = 88;
            classEnter.Text = "ENTER";
            classEnter.UseVisualStyleBackColor = false;
            classEnter.Click += classEnter_Click;
            // 
            // InputLetter
            // 
            InputLetter.AutoSize = true;
            InputLetter.BackColor = Color.Transparent;
            InputLetter.Font = new Font("Arial", 16.2F, FontStyle.Bold);
            InputLetter.ForeColor = Color.White;
            InputLetter.Location = new Point(360, 577);
            InputLetter.Name = "InputLetter";
            InputLetter.Size = new Size(0, 33);
            InputLetter.TabIndex = 89;
            // 
            // groupBox1
            // 
            groupBox1.BackColor = Color.Transparent;
            groupBox1.Font = new Font("Arial", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox1.ForeColor = Color.White;
            groupBox1.Location = new Point(12, 457);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(576, 114);
            groupBox1.TabIndex = 99;
            groupBox1.TabStop = false;
            // 
            // labelWord
            // 
            labelWord.AutoSize = true;
            labelWord.Font = new Font("Arial", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelWord.ForeColor = Color.White;
            labelWord.Location = new Point(280, 585);
            labelWord.Name = "labelWord";
            labelWord.Size = new Size(49, 35);
            labelWord.TabIndex = 100;
            labelWord.Text = "__";
            labelWord.TextAlign = ContentAlignment.TopRight;
            // 
            // pictureHead
            // 
            pictureHead.BackColor = Color.Transparent;
            pictureHead.Image = Properties.Resources.head;
            pictureHead.Location = new Point(259, 188);
            pictureHead.Name = "pictureHead";
            pictureHead.Size = new Size(170, 70);
            pictureHead.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureHead.TabIndex = 101;
            pictureHead.TabStop = false;
            // 
            // pictureLeft
            // 
            pictureLeft.BackColor = Color.Transparent;
            pictureLeft.Image = Properties.Resources.left;
            pictureLeft.Location = new Point(264, 251);
            pictureLeft.Name = "pictureLeft";
            pictureLeft.Size = new Size(56, 117);
            pictureLeft.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureLeft.TabIndex = 104;
            pictureLeft.TabStop = false;
            // 
            // pictureBody
            // 
            pictureBody.BackColor = Color.Transparent;
            pictureBody.Image = Properties.Resources.body;
            pictureBody.Location = new Point(236, 251);
            pictureBody.Name = "pictureBody";
            pictureBody.Size = new Size(215, 136);
            pictureBody.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBody.TabIndex = 105;
            pictureBody.TabStop = false;
            // 
            // pictureRight
            // 
            pictureRight.BackColor = Color.Transparent;
            pictureRight.Image = Properties.Resources.right;
            pictureRight.Location = new Point(367, 251);
            pictureRight.Name = "pictureRight";
            pictureRight.Size = new Size(56, 117);
            pictureRight.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureRight.TabIndex = 106;
            pictureRight.TabStop = false;
            // 
            // pictureLegs
            // 
            pictureLegs.BackColor = Color.Transparent;
            pictureLegs.Image = Properties.Resources.LEGS;
            pictureLegs.Location = new Point(214, 348);
            pictureLegs.Name = "pictureLegs";
            pictureLegs.Size = new Size(262, 100);
            pictureLegs.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureLegs.TabIndex = 107;
            pictureLegs.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(59, 100);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(483, 373);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 98;
            pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(83, 40);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(31, 35);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 108;
            pictureBox3.TabStop = false;
            // 
            // labelLives
            // 
            labelLives.AutoSize = true;
            labelLives.Font = new Font("Arial", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelLives.ForeColor = Color.White;
            labelLives.Location = new Point(124, 42);
            labelLives.Name = "labelLives";
            labelLives.Size = new Size(31, 33);
            labelLives.TabIndex = 109;
            labelLives.Text = "5";
            labelLives.TextAlign = ContentAlignment.TopRight;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.White;
            label3.Location = new Point(208, 40);
            label3.Name = "label3";
            label3.Size = new Size(112, 33);
            label3.TabIndex = 110;
            label3.Text = "Score: ";
            label3.TextAlign = ContentAlignment.TopRight;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Arial", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.White;
            label4.Location = new Point(402, 40);
            label4.Name = "label4";
            label4.Size = new Size(112, 33);
            label4.TabIndex = 111;
            label4.Text = "Streak:";
            label4.TextAlign = ContentAlignment.TopRight;
            // 
            // labelStreak
            // 
            labelStreak.AutoSize = true;
            labelStreak.Font = new Font("Arial", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelStreak.ForeColor = Color.White;
            labelStreak.Location = new Point(514, 40);
            labelStreak.Name = "labelStreak";
            labelStreak.Size = new Size(0, 33);
            labelStreak.TabIndex = 112;
            labelStreak.TextAlign = ContentAlignment.TopRight;
            // 
            // labelScores
            // 
            labelScores.AutoSize = true;
            labelScores.Font = new Font("Arial", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelScores.ForeColor = Color.White;
            labelScores.Location = new Point(306, 40);
            labelScores.Name = "labelScores";
            labelScores.Size = new Size(0, 33);
            labelScores.TabIndex = 113;
            labelScores.TextAlign = ContentAlignment.TopRight;
            // 
            // classHint
            // 
            classHint.BackColor = Color.FromArgb(106, 149, 147);
            classHint.BorderColor = Color.PaleVioletRed;
            classHint.BorderRadius = 30;
            classHint.BorderSize = 0;
            classHint.FlatAppearance.BorderSize = 0;
            classHint.FlatStyle = FlatStyle.Flat;
            classHint.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            classHint.ForeColor = Color.White;
            classHint.Image = Properties.Resources.key__3_;
            classHint.Location = new Point(526, 582);
            classHint.Name = "classHint";
            classHint.Size = new Size(48, 44);
            classHint.TabIndex = 114;
            classHint.UseVisualStyleBackColor = false;
            classHint.Click += classHint_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(91, 105, 128);
            ClientSize = new Size(600, 936);
            Controls.Add(classHint);
            Controls.Add(labelScores);
            Controls.Add(labelStreak);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(labelLives);
            Controls.Add(pictureBox3);
            Controls.Add(pictureLegs);
            Controls.Add(pictureRight);
            Controls.Add(pictureLeft);
            Controls.Add(pictureBody);
            Controls.Add(pictureHead);
            Controls.Add(labelWord);
            Controls.Add(groupBox1);
            Controls.Add(pictureBox2);
            Controls.Add(InputLetter);
            Controls.Add(classEnter);
            Controls.Add(label1);
            Controls.Add(classDelete);
            Controls.Add(classM);
            Controls.Add(classN);
            Controls.Add(classB);
            Controls.Add(classV);
            Controls.Add(classC);
            Controls.Add(classX);
            Controls.Add(classZ);
            Controls.Add(class1p59);
            Controls.Add(class1p60);
            Controls.Add(class1p61);
            Controls.Add(class1p62);
            Controls.Add(class1p63);
            Controls.Add(class1p64);
            Controls.Add(class1p65);
            Controls.Add(class1p66);
            Controls.Add(class1p67);
            Controls.Add(class1p68);
            Controls.Add(class1p69);
            Controls.Add(class1p70);
            Controls.Add(class1p71);
            Controls.Add(class1p72);
            Controls.Add(class1p73);
            Controls.Add(class1p74);
            Controls.Add(class1p75);
            Controls.Add(class1p76);
            Controls.Add(class1p77);
            Controls.Add(class1p78);
            Controls.Add(class1p31);
            Controls.Add(class1p32);
            Controls.Add(class1p33);
            Controls.Add(class1p34);
            Controls.Add(class1p35);
            Controls.Add(class1p36);
            Controls.Add(class1p37);
            Controls.Add(class1p38);
            Controls.Add(class1p39);
            Controls.Add(class1p40);
            Controls.Add(classK);
            Controls.Add(classJ);
            Controls.Add(classL);
            Controls.Add(classH);
            Controls.Add(classG);
            Controls.Add(classF);
            Controls.Add(classD);
            Controls.Add(classS);
            Controls.Add(classA);
            Controls.Add(class1p21);
            Controls.Add(class1p22);
            Controls.Add(class1p23);
            Controls.Add(class1p24);
            Controls.Add(class1p25);
            Controls.Add(class1p26);
            Controls.Add(class1p27);
            Controls.Add(class1p28);
            Controls.Add(class1p29);
            Controls.Add(class1p30);
            Controls.Add(class1p11);
            Controls.Add(class1p12);
            Controls.Add(class1p13);
            Controls.Add(class1p14);
            Controls.Add(class1p15);
            Controls.Add(class1p16);
            Controls.Add(class1p17);
            Controls.Add(class1p18);
            Controls.Add(class1p19);
            Controls.Add(class1p20);
            Controls.Add(class1p9);
            Controls.Add(class1p10);
            Controls.Add(class1p7);
            Controls.Add(class1p8);
            Controls.Add(class1p5);
            Controls.Add(class1p6);
            Controls.Add(class1p3);
            Controls.Add(class1p4);
            Controls.Add(class1p2);
            Controls.Add(pictureBox1);
            Controls.Add(class1p1);
            MaximumSize = new Size(618, 983);
            MinimumSize = new Size(618, 983);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureHead).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureLeft).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBody).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureRight).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureLegs).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Form_Controls.Class1P class1p1;
        private Form_Controls.Class1P class1p2;
        private Form_Controls.Class1P class1p3;
        private Form_Controls.Class1P class1p4;
        private Form_Controls.Class1P class1p5;
        private Form_Controls.Class1P class1p6;
        private Form_Controls.Class1P class1p7;
        private Form_Controls.Class1P class1p8;
        private Form_Controls.Class1P class1p9;
        private Form_Controls.Class1P class1p10;
        private Form_Controls.Class1P class1p11;
        private Form_Controls.Class1P class1p12;
        private Form_Controls.Class1P class1p13;
        private Form_Controls.Class1P class1p14;
        private Form_Controls.Class1P class1p15;
        private Form_Controls.Class1P class1p16;
        private Form_Controls.Class1P class1p17;
        private Form_Controls.Class1P class1p18;
        private Form_Controls.Class1P class1p19;
        private Form_Controls.Class1P class1p20;
        private Form_Controls.Class1P class1p21;
        private Form_Controls.Class1P class1p22;
        private Form_Controls.Class1P class1p23;
        private Form_Controls.Class1P class1p24;
        private Form_Controls.Class1P class1p25;
        private Form_Controls.Class1P class1p26;
        private Form_Controls.Class1P class1p27;
        private Form_Controls.Class1P class1p28;
        private Form_Controls.Class1P class1p29;
        private Form_Controls.Class1P class1p30;
        private Form_Controls.Class1P class1p31;
        private Form_Controls.Class1P class1p32;
        private Form_Controls.Class1P class1p33;
        private Form_Controls.Class1P class1p34;
        private Form_Controls.Class1P class1p35;
        private Form_Controls.Class1P class1p36;
        private Form_Controls.Class1P class1p37;
        private Form_Controls.Class1P class1p38;
        private Form_Controls.Class1P class1p39;
        private Form_Controls.Class1P class1p40;
        private Form_Controls.Class1P classK;
        private Form_Controls.Class1P classJ;
        private Form_Controls.Class1P classL;
        private Form_Controls.Class1P classH;
        private Form_Controls.Class1P classG;
        private Form_Controls.Class1P classF;
        private Form_Controls.Class1P classD;
        private Form_Controls.Class1P classS;
        private Form_Controls.Class1P classA;
        private Form_Controls.Class1P classM;
        private Form_Controls.Class1P classN;
        private Form_Controls.Class1P classB;
        private Form_Controls.Class1P classV;
        private Form_Controls.Class1P classC;
        private Form_Controls.Class1P classX;
        private Form_Controls.Class1P classZ;
        private Form_Controls.Class1P class1p59;
        private Form_Controls.Class1P class1p60;
        private Form_Controls.Class1P class1p61;
        private Form_Controls.Class1P class1p62;
        private Form_Controls.Class1P class1p63;
        private Form_Controls.Class1P class1p64;
        private Form_Controls.Class1P class1p65;
        private Form_Controls.Class1P class1p66;
        private Form_Controls.Class1P class1p67;
        private Form_Controls.Class1P class1p68;
        private Form_Controls.Class1P class1p69;
        private Form_Controls.Class1P class1p70;
        private Form_Controls.Class1P class1p71;
        private Form_Controls.Class1P class1p72;
        private Form_Controls.Class1P class1p73;
        private Form_Controls.Class1P class1p74;
        private Form_Controls.Class1P class1p75;
        private Form_Controls.Class1P class1p76;
        private Form_Controls.Class1P class1p77;
        private Form_Controls.Class1P class1p78;
        private PictureBox pictureBox1;
        private Form_Controls.Class1P classDelete;
        private Label label1;
        private Form_Controls.Class1P classEnter;
        private Label InputLetter;
        private GroupBox groupBox1;
        private Label labelWord;
        private PictureBox pictureHead;
        private PictureBox pictureLeft;
        private PictureBox pictureBody;
        private PictureBox pictureRight;
        private PictureBox pictureLegs;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
        private Label labelLives;
        private Label label3;
        private Label label4;
        private Label labelStreak;
        private Label labelScores;
        private Form_Controls.Class1P classHint;
    }
}
