namespace DSA_Final
{
    using Microsoft.VisualBasic.ApplicationServices;
    using System.IO;
    public partial class Form1 : Form
    {
        string word = "";
        List<Label> labels = new List<Label>();
        List<Button> allButtons = new List<Button>();
        private int bodyparts = 0;
        private int lives = 5;
        private PictureBox[] bodyPartPictures;
        private Button lastClickedButton = null;
        private int streak = 0;
        private int scores = 0;
        Queue<string> hintQueue = new Queue<string>();
        private string wordFilePath = "C:\\Users\\crist\\source\\repos\\DSA_Final\\DSA_Final\\Properties\\Hangman-Words.txt";

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            MakeLabels();
            bodyPartPictures = new PictureBox[]
            {
                pictureHead,
                pictureBody,
                pictureLeft,
                pictureRight,
                pictureLegs
            };

            foreach (var pictureBox in bodyPartPictures)
            {
                pictureBox.Hide();
            }
            InitializeButtons();
        }

        private void InitializeButtons()
        {
            allButtons.Add(class1p1);
            allButtons.Add(class1p2);
            allButtons.Add(class1p3);
            allButtons.Add(class1p4);
            allButtons.Add(class1p5);
            allButtons.Add(class1p6);
            allButtons.Add(class1p7);
            allButtons.Add(class1p8);
            allButtons.Add(class1p9);
            allButtons.Add(class1p10);
            allButtons.Add(classZ);
            allButtons.Add(classX);
            allButtons.Add(classC);
            allButtons.Add(classV);
            allButtons.Add(classB);
            allButtons.Add(classN);
            allButtons.Add(classM);
            allButtons.Add(classA);
            allButtons.Add(classS);
            allButtons.Add(classD);
            allButtons.Add(classF);
            allButtons.Add(classG);
            allButtons.Add(classH);
            allButtons.Add(classJ);
            allButtons.Add(classK);
            allButtons.Add(classL);

            // Attach the common event handler to all buttons
            foreach (Button btn in allButtons)
            {
                btn.Click += LetterButton_Click;
            }
        }

        private void LetterButton_Click(object sender, EventArgs e)
        {
            Button clickedButton = sender as Button;

            if (clickedButton != null)
            {
                labelWord.Text = clickedButton.Text;
                clickedButton.BackColor = Color.Gray;
                clickedButton.ForeColor = Color.White;
                clickedButton.Enabled = false;
                lastClickedButton = clickedButton;
            }
        }

        string GetWord()
        {
            string wordList = File.ReadAllText(wordFilePath);
            string[] words = wordList.Split(new[] { '\n', ' ' }, StringSplitOptions.RemoveEmptyEntries);
            Random ran = new Random();
            return words[ran.Next(0, words.Length)].Trim();
        }

        void MakeLabels()
        {
            word = GetWord().ToUpper();
            char[] chars = word.ToCharArray();

            int groupBoxWidth = groupBox1.Width;
            int labelSpacing = 50;
            int totalLabelWidth = chars.Length * labelSpacing;

            int startX = (groupBoxWidth - totalLabelWidth) / 2;

            for (int i = 0; i < chars.Length; i++)
            {
                Label lbl = new Label();
                lbl.Location = new Point(startX + (i * labelSpacing), groupBox1.Height / 2 - 10);
                lbl.Text = "_";
                lbl.AutoSize = true;
                lbl.Font = new Font("Arial", 18, FontStyle.Bold);

                groupBox1.Controls.Add(lbl);
                labels.Add(lbl);
            }
            GenerateHints();
        }

        private void ResetButtons()
        {
            if (lastClickedButton != null)
            {
                lastClickedButton.BackColor = ColorTranslator.FromHtml("#6a9593");
                lastClickedButton.ForeColor = Color.White;
                lastClickedButton.Enabled = true;
            }
        }

        private void classEnter_Click(object sender, EventArgs e)
        {
            char letter = labelWord.Text.ToCharArray()[0];
            if (word.Contains(letter))
            {
                char[] letters = word.ToCharArray();
                for (int i = 0; i < letters.Length; i++)
                {
                    if (letters[i] == letter)
                    {
                        labels[i].Text = letter.ToString();
                    }
                }
            }
            else
            {
                if (bodyparts < bodyPartPictures.Length)
                {
                    bodyPartPictures[bodyparts].Show();
                    bodyparts++;
                }
            }

            if (bodyparts >= bodyPartPictures.Length)
            {
                MessageBox.Show("Game Over! You've lost all lives.");
                ResetGame();
                lives--;
                labelLives.Text = lives.ToString();
            }
            else if (IsWordGuessed())
            {
                streak++;
                UpdateScoresBasedOnStreak();
                CheckAndUpdateDifficulty();
                MessageBox.Show("Congratulations! You've guessed the word!");
                ResetGame();
            }
        }

        private void UpdateScoresBasedOnStreak()
        {
            if (streak <= 5)
            {
                scores += 100;
            }
            else if (streak <= 10)
            {
                scores += 200;
            }
            else if (streak <= 20)
            {
                scores += 300;
            }
            else if (streak <= 30)
            {
                scores += 500;
            }
            else
            {
                scores += 1000;
            }

            labelScores.Text = scores.ToString();
            labelStreak.Text = streak.ToString();
        }

        private void CheckAndUpdateDifficulty()
        {
            if (streak == 10)
            {
                wordFilePath = "C:\\Users\\crist\\source\\repos\\DSA_Final\\DSA_Final\\Properties\\Hangman-Words - Copy.txt";
                MessageBox.Show("Difficulty increased to Medium!");
            }else if(streak == 20)
            {
                wordFilePath = "C:\\Users\\crist\\source\\repos\\DSA_Final\\DSA_Final\\Properties\\Hangman-Words - Copy (2).txt";
                MessageBox.Show("Difficulty increased to Medium!");
            }
        }


        private void ResetGame()
        {
            bodyparts = 0;
            labelLives.Text = lives.ToString();
            labelScores.Text = scores.ToString();
            labelStreak.Text = streak.ToString();

            foreach (var pictureBox in bodyPartPictures)
            {
                pictureBox.Hide();
            }

            foreach (Label lbl in labels)
            {
                groupBox1.Controls.Remove(lbl);
            }
            labels.Clear();

            MakeLabels();

            foreach (Button btn in allButtons)
            {
                btn.Enabled = true;
                btn.BackColor = ColorTranslator.FromHtml("#6a9593");
                btn.ForeColor = Color.White;
            }
            labelWord.Text = "_";
        }

        private bool IsWordGuessed()
        {
            foreach (Label lbl in labels)
            {
                if (lbl.Text == "_")
                {
                    return false;
                }
            }
            return true;
        }

        private void classDelete_Click(object sender, EventArgs e)
        {
            labelWord.Text = "_";
            ResetButtons();
        }

        private void GenerateHints()
        {
            List<int> unguessedPositions = new List<int>();

            for (int i = 0; i < word.Length; i++)
            {
                if (labels[i].Text == "_")
                {
                    unguessedPositions.Add(i);
                }
            }

            Random random = new Random();
            while (hintQueue.Count < 3 && unguessedPositions.Count > 0)
            {
                int randomIndex = random.Next(unguessedPositions.Count);
                int hintPosition = unguessedPositions[randomIndex];
                hintQueue.Enqueue(word[hintPosition].ToString());
                unguessedPositions.RemoveAt(randomIndex);
            }
        }

        private void ShowHint()
        {
            if (hintQueue.Count > 0)
            {
                string hint = hintQueue.Dequeue();
                for (int i = 0; i < word.Length; i++)
                {
                    if (word[i].ToString() == hint && labels[i].Text == "_")
                    {
                        labels[i].Text = hint;
                        break;
                    }
                }
            }
            else
            {
                MessageBox.Show("No more hints available!");
            }
        }

        private void classHint_Click(object sender, EventArgs e)
        {
            ShowHint();
        }
    }
}
